(function() {
    var __sections__ = {};
    (function() {
        for (var i = 0, s = document.getElementById("sections-script").getAttribute("data-sections").split(","); i < s.length; i++) __sections__[s[i]] = !0
    })(),
    function() {
        if (__sections__["promo-fixed"]) try {
            var initPromoFixed2 = function() {
                    var $ttpromofixed = $(".tt-promo-fixed"),
                        $promofixeddata = $(".promofixeddata"),
                        $promofixedclose = $ttpromofixed.find(".tt-btn-close");
                    if ($("html").hasClass("touch-device") && $ttpromofixed.hasClass("hidden-mobile") || $ttpromofixed.hasClass("hidden-mobile") && $(window).width < 1025 || $promofixeddata.length == 0) return !1;
                    setPromoFixedItem2($ttpromofixed, $promofixeddata), showPromoFixed2($ttpromofixed, $ttpromofixed.data("start")), showPromoFixedNextMessage2($ttpromofixed, $promofixeddata, $promofixedclose), $promofixedclose.click(function() {
                        $ttpromofixed.addClass("nonevent").fadeTo(100, 0)
                    })
                },
                showPromoFixedNextMessage2 = function($modal, $data, $close) {
                    var nextmin = $modal.data("min"),
                        nextmax = $modal.data("max"),
                        i = getRndInteger2(nextmin, nextmax);
                    setTimeout(function() {
                        $close.trigger("click"), setTimeout(function() {
                            setPromoFixedItem2($modal, $data), showPromoFixed2($modal, 0), showPromoFixedNextMessage2($modal, $data, $close)
                        }, 100)
                    }, i)
                },
                getPromoFixedCustomProductIndex2 = function($promofixeddata) {
                    var min = 0,
                        max = $promofixeddata.children().length;
                    return getRndInteger2(min, max)
                },
                setPromoFixedItem2 = function($modal, $data) {
                    var i = getPromoFixedCustomProductIndex2($data),
                        data = $data.children().eq(i);
                    $modal.find(".tt-img").find("a").attr("href", data.data("url")).find("img").attr("src", data.data("image")).attr("alt", data.data("alt")), $modal.find(".pr_name").attr("href", data.data("url")).text(data.data("name"));
                    var nummin = parseInt(data.data("min")),
                        nummax = parseInt(data.data("max")),
                        num = getRndInteger2(nummin, nummax);
                    if ($modal.find(".tt-info-value").text(num), typeof data.data("text") == "undefined") return !1;
                    var str = data.data("text").split("||"),
                        i = getRndInteger2(0, str.length - 1);
                    $modal.find(".tt-info-text").text(str[i])
                },
                showPromoFixed2 = function($parent, delay) {
                    setTimeout(function() {
                        $parent.removeClass("nonevent").fadeTo(300, 1)
                    }, delay)
                },
                getRndInteger2 = function(min, max) {
                    return Math.floor(Math.random() * (max - min)) + min
                },
                initPromoFixed = initPromoFixed2,
                showPromoFixedNextMessage = showPromoFixedNextMessage2,
                getPromoFixedCustomProductIndex = getPromoFixedCustomProductIndex2,
                setPromoFixedItem = setPromoFixedItem2,
                showPromoFixed = showPromoFixed2,
                getRndInteger = getRndInteger2;
            setTimeout(initPromoFixed2, 300)
        } catch (e) {
            console.error(e)
        }
    }()
})();
//# sourceMappingURL=/cdn/shop/t/11/compiled_assets/scripts.js.map?6153=