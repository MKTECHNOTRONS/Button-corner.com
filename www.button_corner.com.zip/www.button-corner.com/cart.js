{
    "token": "150934e8d25a92018e78e05282f62db0",
    "note": null,
    "attributes": {},
    "original_total_price": 0,
    "total_price": 0,
    "total_discount": 0,
    "total_weight": 0.0,
    "item_count": 0,
    "items": [],
    "requires_shipping": false,
    "currency": "PKR",
    "items_subtotal_price": 0,
    "cart_level_discount_applications": []
}